# VECTOR
Minecraft on an Oscilloscope

## Features
- Retro Computing effects
- PBR Resource Pack support
- Highly customisable
- Fine-tuned Presets

## Requirements
- Recent Optifine or Iris
- Minecraft 1.17 or later
  - May partially work on earlier versions

## Known Issues
- With PBR Resource packs, lines may become very dense. Increase or disable `[LINE NORMAL THRESHOLD]` in `[LINE SHAPE]` settings.
- With long render distances, far away details may become very dense. Decrease render distance, increase/disable `[LINE NORMAL THRESHOLD]` in `[LINE SHAPE]` settings, or enable and reduce the `[DISTANCE BIAS™ SYSTEM]` in `[LINE SHAPE]`.
- **On Iris**, entity circle shadows appear square and may jitter depending on the viewing angle. Disable entity shadows in Iris/Sodium settings.
- Under certain conditions the sun or moon may appear to have a large outline. Disable sun/moon in the Optifine/Iris/Sodium settings.
- **On Optifine**, the PLAYER HUD option cannot be used. If a player toggles it on, a warning will be shown.
