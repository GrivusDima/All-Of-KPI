#version 120
//#extension GL_ARB_shader_texture_lod : disable

#include "/lib/settings.glsl"

flat varying int water;
varying vec2 texcoord;

varying float overdrawCull;

uniform sampler2D tex;
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////

void main() {

    if(water > 0){   
        discard;
        return;
    }
    
    if(overdrawCull < 1.0){   
        discard;
        return;
    }
    
	gl_FragData[0] = texture2D(tex, texcoord.xy);
}
